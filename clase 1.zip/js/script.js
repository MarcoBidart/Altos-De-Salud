let entrada1 = prompt('Antes de comezar ingresa tu Nombre');
let entrada2 = prompt("Ahora ingresa tu Apellido")
let salida = entrada1 + ' ' + entrada2 + ' ' + 'Has ingresado Correctamente tus Datos';
alert(salida);